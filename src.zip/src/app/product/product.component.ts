import { Component, OnInit,Inject, ChangeDetectionStrategy} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogData } from '../DialogData';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<ProductComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData) {
      for (let index = 1; index < 99000; index++) {
        this.scrollItems.push(index);
      }
    }

  onNoClick(): void {
    this.dialogRef.close();
  }
  scrollItems: number[] = [];

 
  ngOnInit() {
  }

}
