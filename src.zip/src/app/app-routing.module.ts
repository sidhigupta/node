import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { PlaceComponent } from './place/place.component';
import { ServiceComponent } from './service/service.component';
import { ProductComponent } from './product/product.component';
import { UserdataComponent } from './userdata/userdata.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CsvComponent } from './csv/csv.component';
import { AdminComponent } from './admin/admin.component';
import { ChartComponent } from './chart/chart.component';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'place', component: PlaceComponent },
  { path: 'service', component: ServiceComponent },
  { path: 'product', component: ProductComponent },
  { path: 'userdata', component: UserdataComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'policy-list', component: PolicyListComponent },
  { path: 'chart', component: ChartComponent },
  { path: 'csv', component: CsvComponent },
  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  
}
