import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
//import { ApiService } from '../api.service';
//import { ContactService } from '../contact.service';
//import { NgFlashMessagesModule } from 'ng-flash-messages';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  messageForm: FormGroup;
  submitted = false;
  success = false;
  title: string = 'Our Location';
  lat: number = 51.678418;
  lng: number = 7.809007;
  //private contactService: ContactService
  constructor(private formBuilder: FormBuilder) { 
    //this.createForm();
  }
  

  ngOnInit() {
    this.messageForm = this.formBuilder.group({
      name: ['', [Validators.required,Validators.minLength(6)]],
      email: ['', [Validators.required,Validators.email]],
      phone: ['', [Validators.required,  Validators.minLength(1),
        Validators.maxLength(10),Validators.pattern('[0-9]+')]],
      message: ['', Validators.required]
    });
  }
  // createForm() {
  //   this.messageForm = this.formBuilder.group({
  //     to: ['', [Validators.required,Validators.minLength(6)]],
  //     email: ['', [Validators.required,Validators.email]],
  //     phone: ['', [Validators.required,  Validators.minLength(1),
  //       Validators.maxLength(10),Validators.pattern('[0-9]+')]],
  //     body: ['', Validators.required]
  //   });
  // }
  // sendMail(name, email, message) {
  //   this.contactService.sendEmail(name, email, message).subscribe(success => {
  //     this.flashMessages.show('You are data we succesfully submitted', { cssClass: 'alert-success', timeout: 3000 });
  //     console.log(success);
  //   }, error => {
  //     this.flashMessages.show('Something went wrong', { cssClass: 'alert-danger', timeout: 3000 });
  //   });
  // }

  onSubmit() {
    this.submitted = true;

    if (this.messageForm.invalid) {
        return;
    }

    this.success = true;
}

}
// import { Component, OnInit } from '@angular/core';
// import { ContactService } from '../contact.service';
// import { FormGroup, FormBuilder, Validators } from '@angular/forms';
// import { FlashMessagesModule, FlashMessagesService } from 'angular2-flash-messages';
// @Component({
//   selector: 'app-contact',
//   templateUrl: './contact.component.html',
//   styleUrls: ['./contact.component.css']
// })
// export class ContactComponent implements OnInit {
//   angForm: FormGroup;
//   constructor(
//     private flashMessages: FlashMessagesService,
//     private fb: FormBuilder,
//     private contactService: ContactService) {
//     this.createForm();
//   }

//   createForm() {
//     this.angForm = this.fb.group({
//       name: ['', Validators.required],
//       email: ['', Validators.required],
//       message: ['', Validators.required],
//     });
//   }
//   sendMail(name, email, message) {
//     this.contactService.sendEmail(name, email, message).subscribe(success => {
//       this.flashMessages.show('You are data we succesfully submitted', { cssClass: 'alert-success', timeout: 3000 });
//       console.log(success);
//     }, error => {
//       this.flashMessages.show('Something went wrong', { cssClass: 'alert-danger', timeout: 3000 });
//     });
//   }
//   ngOnInit() {
//   }

// }