import { Policy } from './policy.model';

describe('Policy', () => {
  it('should create an instance', () => {
    expect(new Policy()).toBeTruthy();
  });
});
