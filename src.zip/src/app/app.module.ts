import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
//import {Sort} from '@angular/material';
import { AngularFireModule } from '@angular/fire';
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { MaterialModule } from './material.module';
import { environment } from '../environments/environment';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { JwtModule } from '@auth0/angular-jwt';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatPaginatorModule} from '@angular/material/paginator';
import { AgmCoreModule } from '@agm/core';
import { NgFlashMessagesModule } from 'ng-flash-messages';
import { FlashMessagesModule } from 'angular2-flash-messages';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatAutocompleteModule, MatInputModule, MatCheckboxModule, MatTableModule, MatRadioModule, MatSliderModule, MatDatepickerModule, MatNativeDateModule,MatOptionModule, MatSelectModule, MatIconModule} from '@angular/material';
import { ListComponent } from './components/list/list.component';
import { CreateComponent } from './components/create/create.component';
import { EditComponent } from './components/edit/edit.component';
import { NavComponent } from './nav/nav.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { ServiceComponent } from './service/service.component';
import { FooterComponent } from './footer/footer.component';
import { PlaceComponent } from './place/place.component';
import { ProductComponent } from './product/product.component';
import { UserdataComponent } from './userdata/userdata.component';
import { BusinessService } from './business.service';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent }  from './app.component';
import { CsvComponent } from './csv/csv.component';
import { AdminComponent } from './admin/admin.component';
import { ChartComponent } from './chart/chart.component';
import { PolicyListComponent } from './policy-list/policy-list.component';
import { FileSelectDirective } from 'ng2-file-upload';
import { NgxSmartModalModule } from 'ngx-smart-modal';
import { AngularFileUploaderModule } from "angular-file-uploader";
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DialogData } from './DialogData';
import {DragDropModule} from '@angular/cdk/drag-drop';
 const routes: Routes = [
    { path: 'create', component: CreateComponent },
    { path: 'edit/:id', component: EditComponent },
    { path: 'list', component: ListComponent },
    { path: '', redirectTo: '/list', pathMatch: 'full'}
  ];
@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    CreateComponent,
    EditComponent,
    NavComponent,
    AboutComponent,
    ContactComponent,
    HomeComponent,
    ServiceComponent,
    FooterComponent,
    PlaceComponent,
    ProductComponent,
    UserdataComponent,FileSelectDirective,
    LoginComponent,
    RegisterComponent,
    CsvComponent,
    AdminComponent,
    ChartComponent,
    PolicyListComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, NgFlashMessagesModule.forRoot(),
    BrowserAnimationsModule,DragDropModule,FlashMessagesModule.forRoot(),
    MatAutocompleteModule,AngularFontAwesomeModule,
    MatCheckboxModule,MatSliderModule, MatTableModule,MatProgressSpinnerModule,
    MatOptionModule, MatSelectModule, MatIconModule, MatRadioModule, ScrollingModule,
    MatDatepickerModule, MatInputModule,MatNativeDateModule, MatPaginatorModule,MaterialModule,
    MatInputModule,AgmCoreModule.forRoot({
      apiKey: 'CHAVES_GOOGLE_MAPS'
    }),
    AngularFireModule.initializeApp(environment.firebaseConfig),
    AngularFireDatabaseModule,  AngularFileUploaderModule,
    HttpClientModule, NgxSmartModalModule.forRoot(),
    FormsModule, MDBBootstrapModule.forRoot(),    // <-- Right here-->
    ReactiveFormsModule,  // <- Add here-->
    JwtModule.forRoot({
      config: {
        tokenGetter: function  tokenGetter() {
             return     localStorage.getItem('access_token');},
        whitelistedDomains: ['localhost:2000'],
        blacklistedRoutes: ['http://localhost:2000/auth/login']
      }
    }),
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule {}
