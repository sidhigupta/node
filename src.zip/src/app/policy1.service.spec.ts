import { TestBed } from '@angular/core/testing';

import { Policy1Service } from './policy1.service';

describe('Policy1Service', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: Policy1Service = TestBed.get(Policy1Service);
    expect(service).toBeTruthy();
  });
});
