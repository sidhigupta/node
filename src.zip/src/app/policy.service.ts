import { Injectable } from '@angular/core';
export  class  Policy {
  id: number;
  number:  number;
  amount:  number;
}
@Injectable({
  providedIn: 'root'
})
export class PolicyService {
  
  constructor() { }
}
