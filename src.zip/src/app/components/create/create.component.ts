import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../../myservice.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  newcomponent = "Entered in new component created";
  title = 'Mattsen Kumar';
  todaydate;
  constructor(private myservice: MyserviceService) {}
  ngOnInit() {
     this.todaydate = this.myservice.showTodayDate();
  }
  // todaydate;
  //  componentproperty;
  //  constructor(private myservice: MyserviceService) {}
  //  ngOnInit() {
  //     this.todaydate = this.myservice.showTodayDate();
  //     console.log(this.myservice.serviceproperty);
  //     this.myservice.serviceproperty = "component created"; // value is changed.
  //     this.componentproperty = this.myservice.serviceproperty;
  //  }
   months = ["January", "Feburary", "March", "April", "May", 
            "June", "July", "August", "September",
            "October", "November", "December"];
            isavailable = true;   //variable is set to true
            myClickFunction(event) { 
              //just added console.log which will display the event details in browser on click of the button.
              alert("Button is clicked");
              console.log(event);
           }
           changemonths(event) {
            console.log("Changed month from the Dropdown");
            console.log(event);
         }

}